class RemoveSomeColumnsShows < ActiveRecord::Migration
  def self.up
    remove_column :shows, :description
    remove_column :shows, :release_date
  end

  def self.down
  end
end
