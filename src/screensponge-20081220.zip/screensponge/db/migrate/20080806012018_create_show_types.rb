class CreateShowTypes < ActiveRecord::Migration
  def self.up
#    create_table :show_types do |t|
#      t.string :name
#      t.text :description
#    end
#    
#    ShowType.create :name => "movie", :description => "Full feature Movie"
#        ShowType.create :name => "short film", :description => "Short film"
#        ShowType.create :name => "web clip", :description => "Short video clip"
#        ShowType.create :name => "tv series", :description => "Television series"
#        ShowType.create :name => "tv season", :description => "Television season"
#        ShowType.create :name => "tv episode", :description => "Television episode"
#        ShowType.create :name => "other", :description => "Other"
  end

  def self.down
#    drop_table :show_types
  end
end
