class DropShowTypeFromShows < ActiveRecord::Migration
  def self.up
    remove_column :shows, :show_type_id
  end

  def self.down
  end
end
