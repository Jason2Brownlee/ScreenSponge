class AddTypeToShows < ActiveRecord::Migration
  def self.up
    add_column :shows, :show_type, :string
  end

  def self.down
    remove_column :shows, :type
  end
end
