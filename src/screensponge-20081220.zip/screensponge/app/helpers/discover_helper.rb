module DiscoverHelper
  
  def discover_tab
    return "discover" if logged_in?
    return "shows"
  end
  
end
