module ActivitiesHelper
end
