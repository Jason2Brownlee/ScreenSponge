class Rating < ActiveRecord::Base
  belongs_to :show
end
